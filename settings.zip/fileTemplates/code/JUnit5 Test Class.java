import static org.assertj.core.api.Assertions.assertThat;

#parse("File Header.java")
class ${NAME} {
  ${BODY}
}